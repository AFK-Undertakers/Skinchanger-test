// Generated using https://github.com/a2x/cs2-dumper
// 2026-04-03 10:56:29.533035500 UTC

namespace CS2Dumper.Interfaces {
    // Module: animationsystem.dll
    public static class AnimationsystemDll {
        public const nint AnimationSystemUtils_001 = 0x7F25B8;
        public const nint AnimationSystem_001 = 0x7EA4D0;
    }
    // Module: client.dll
    public static class ClientDll {
        public const nint ClientToolsInfo_001 = 0x2065F90;
        public const nint EmptyWorldService001_Client = 0x201FE50;
        public const nint GameClientExports001 = 0x2062C70;
        public const nint LegacyGameUI001 = 0x20804D0;
        public const nint Source2Client002 = 0x230CDD0;
        public const nint Source2ClientConfig001 = 0x2290F00;
        public const nint Source2ClientPrediction001 = 0x206D8F0;
        public const nint Source2ClientUI001 = 0x207ED60;
    }
    // Module: engine2.dll
    public static class Engine2Dll {
        public const nint BenchmarkService001 = 0x614930;
        public const nint BugService001 = 0x8C9E10;
        public const nint ClientServerEngineLoopService_001 = 0x90B4B0;
        public const nint EngineGameUI001 = 0x6122E0;
        public const nint EngineServiceMgr001 = 0x90AD60;
        public const nint GameEventSystemClientV001 = 0x90B040;
        public const nint GameEventSystemServerV001 = 0x90B170;
        public const nint GameResourceServiceClientV001 = 0x614A30;
        public const nint GameResourceServiceServerV001 = 0x614A90;
        public const nint GameUIService_001 = 0x8CA240;
        public const nint HostStateMgr001 = 0x6152B0;
        public const nint INETSUPPORT_001 = 0x60D8E0;
        public const nint InputService_001 = 0x8CA530;
        public const nint KeyValueCache001 = 0x615360;
        public const nint MapListService_001 = 0x9093A0;
        public const nint NetworkClientService_001 = 0x909530;
        public const nint NetworkP2PService_001 = 0x909870;
        public const nint NetworkServerService_001 = 0x909A20;
        public const nint NetworkService_001 = 0x614C00;
        public const nint RenderService_001 = 0x909C90;
        public const nint ScreenshotService001 = 0x909F50;
        public const nint SimpleEngineLoopService_001 = 0x6153C0;
        public const nint SoundService_001 = 0x614C40;
        public const nint Source2EngineToClient001 = 0x611BE0;
        public const nint Source2EngineToClientStringTable001 = 0x611C40;
        public const nint Source2EngineToServer001 = 0x611CB8;
        public const nint Source2EngineToServerStringTable001 = 0x611CE0;
        public const nint SplitScreenService_001 = 0x614F20;
        public const nint StatsService_001 = 0x90A310;
        public const nint ToolService_001 = 0x6150E0;
        public const nint VENGINE_GAMEUIFUNCS_VERSION005 = 0x612370;
        public const nint VProfService_001 = 0x615120;
    }
    // Module: filesystem_stdio.dll
    public static class FilesystemStdioDll {
        public const nint VAsyncFileSystem2_001 = 0x214970;
        public const nint VFileSystem017 = 0x214730;
    }
    // Module: host.dll
    public static class HostDll {
        public const nint DebugDrawQueueManager001 = 0x139020;
        public const nint GameModelInfo001 = 0x139060;
        public const nint GameSystem2HostHook = 0x1390A0;
        public const nint HostUtils001 = 0x1467E0;
        public const nint PredictionDiffManager001 = 0x1391B0;
        public const nint SaveRestoreDataVersion001 = 0x1392E0;
        public const nint SinglePlayerSharedMemory001 = 0x139310;
        public const nint Source2Host001 = 0x139380;
    }
    // Module: imemanager.dll
    public static class ImemanagerDll {
        public const nint IMEManager001 = 0x36AA0;
    }
    // Module: inputsystem.dll
    public static class InputsystemDll {
        public const nint InputStackSystemVersion001 = 0x43DD0;
        public const nint InputSystemVersion001 = 0x45AD0;
    }
    // Module: localize.dll
    public static class LocalizeDll {
        public const nint Localize_001 = 0x57E20;
    }
    // Module: matchmaking.dll
    public static class MatchmakingDll {
        public const nint GameTypes001 = 0x1B8000;
        public const nint MATCHFRAMEWORK_001 = 0x1C02B0;
    }
    // Module: materialsystem2.dll
    public static class Materialsystem2Dll {
        public const nint FontManager_001 = 0x164570;
        public const nint MaterialUtils_001 = 0x14C5C0;
        public const nint PostProcessingSystem_001 = 0x14C4D0;
        public const nint TextLayout_001 = 0x14C550;
        public const nint VMaterialSystem2_001 = 0x163E80;
    }
    // Module: meshsystem.dll
    public static class MeshsystemDll {
        public const nint MeshSystem001 = 0x1506A0;
    }
    // Module: navsystem.dll
    public static class NavsystemDll {
        public const nint NavSystem001 = 0x1269E0;
    }
    // Module: networksystem.dll
    public static class NetworksystemDll {
        public const nint FlattenedSerializersVersion001 = 0x27B7C0;
        public const nint NetworkMessagesVersion001 = 0x2A3950;
        public const nint NetworkSystemVersion001 = 0x294F80;
        public const nint SerializedEntitiesVersion001 = 0x295070;
    }
    // Module: panorama.dll
    public static class PanoramaDll {
        public const nint PanoramaUIEngine001 = 0x507CB0;
    }
    // Module: panorama_text_pango.dll
    public static class PanoramaTextPangoDll {
        public const nint PanoramaTextServices001 = 0x2B89C0;
    }
    // Module: panoramauiclient.dll
    public static class PanoramauiclientDll {
        public const nint PanoramaUIClient001 = 0x295380;
    }
    // Module: particles.dll
    public static class ParticlesDll {
        public const nint ParticleSystemMgr003 = 0x520E70;
    }
    // Module: pulse_system.dll
    public static class PulseSystemDll {
        public const nint IPulseSystem_001 = 0x1F2670;
    }
    // Module: rendersystemdx11.dll
    public static class Rendersystemdx11Dll {
        public const nint RenderDeviceMgr001 = 0x432D30;
        public const nint RenderUtils_001 = 0x433628;
        public const nint VRenderDeviceMgrBackdoor001 = 0x432DD0;
    }
    // Module: resourcesystem.dll
    public static class ResourcesystemDll {
        public const nint ResourceSystem013 = 0x81FE0;
    }
    // Module: scenefilecache.dll
    public static class ScenefilecacheDll {
        public const nint ResponseRulesCache001 = 0xDB190;
        public const nint SceneFileCache002 = 0xDB2C0;
    }
    // Module: scenesystem.dll
    public static class ScenesystemDll {
        public const nint RenderingPipelines_001 = 0x65BAD0;
        public const nint SceneSystem_002 = 0x8CFEE0;
        public const nint SceneUtils_001 = 0x65C9E0;
    }
    // Module: schemasystem.dll
    public static class SchemasystemDll {
        public const nint SchemaSystem_001 = 0x76730;
    }
    // Module: server.dll
    public static class ServerDll {
        public const nint EmptyWorldService001_Server = 0x1B78A90;
        public const nint EntitySubclassUtilsV001 = 0x1B24160;
        public const nint NavGameTest001 = 0x1C226D8;
        public const nint ServerToolsInfo_001 = 0x1BD3978;
        public const nint Source2GameClients001 = 0x1BD09F0;
        public const nint Source2GameDirector001 = 0x1D628D0;
        public const nint Source2GameEntities001 = 0x1BD3080;
        public const nint Source2Server001 = 0x1BD2EE0;
        public const nint Source2ServerConfig001 = 0x1E57B18;
        public const nint customnavsystem001 = 0x1B02F58;
    }
    // Module: soundsystem.dll
    public static class SoundsystemDll {
        public const nint SoundOpSystem001 = 0x4F3AA0;
        public const nint SoundOpSystemEdit001 = 0x4F3980;
        public const nint SoundSystem001 = 0x4F3470;
        public const nint VMixEditTool001 = 0x59472FF;
    }
    // Module: steamaudio.dll
    public static class SteamaudioDll {
        public const nint SteamAudio001 = 0x25C440;
    }
    // Module: steamclient64.dll
    public static class Steamclient64Dll {
        public const nint IVALIDATE001 = 0x16998B8;
        public const nint SteamClient006 = 0x1696D50;
        public const nint SteamClient007 = 0x1696D58;
        public const nint SteamClient008 = 0x1696D60;
        public const nint SteamClient009 = 0x1696D68;
        public const nint SteamClient010 = 0x1696D70;
        public const nint SteamClient011 = 0x1696D78;
        public const nint SteamClient012 = 0x1696D80;
        public const nint SteamClient013 = 0x1696D88;
        public const nint SteamClient014 = 0x1696D90;
        public const nint SteamClient015 = 0x1696D98;
        public const nint SteamClient016 = 0x1696DA0;
        public const nint SteamClient017 = 0x1696DA8;
        public const nint SteamClient018 = 0x1696DB0;
        public const nint SteamClient019 = 0x1696DB8;
        public const nint SteamClient020 = 0x1696DC0;
        public const nint SteamClient021 = 0x1696DC8;
        public const nint SteamClient022 = 0x1696DD0;
        public const nint SteamClient023 = 0x1696DD8;
        public const nint p2pvoice002 = 0x14E5DEF;
        public const nint p2pvoicesingleton002 = 0x16720F0;
    }
    // Module: tier0.dll
    public static class Tier0Dll {
        public const nint TestScriptMgr001 = 0x398620;
        public const nint VEngineCvar007 = 0x3A33B0;
        public const nint VProcessUtils002 = 0x3985C0;
        public const nint VStringTokenSystem001 = 0x3CA090;
    }
    // Module: v8system.dll
    public static class V8systemDll {
        public const nint Source2V8System001 = 0x316B0;
    }
    // Module: vconcomm.dll
    public static class VconcommDll {
        public const nint VConComm001 = 0x39540;
    }
    // Module: vphysics2.dll
    public static class Vphysics2Dll {
        public const nint VPhysics2_Handle_Interface_001 = 0x4000E0;
        public const nint VPhysics2_Interface_001 = 0x400120;
    }
    // Module: vscript.dll
    public static class VscriptDll {
        public const nint VScriptManager010 = 0x13B390;
    }
    // Module: vstdlib_s64.dll
    public static class VstdlibS64Dll {
        public const nint IVALIDATE001 = 0x6F990;
        public const nint VEngineCvar002 = 0x6E070;
    }
    // Module: worldrenderer.dll
    public static class WorldrendererDll {
        public const nint WorldRendererMgr001 = 0x214A00;
    }
}
